package modulo;

public enum TipoUsuario {
    ADMINISTRADOR,
    RECEPCIONISTA,
    HOSPEDE;
}
