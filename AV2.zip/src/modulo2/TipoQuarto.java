package modulo2;

public enum TipoQuarto {
    LUXO_SIMPLES,
    LUXO_DUPLO,
    PRESIDENCIAL;
}
